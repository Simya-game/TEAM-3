# 괴담 근무일지 — GitHub Pages / 휴대폰 앱(PWA) 버전

휴대폰 크롬에서 **앱처럼 설치**하고, **인터넷이 없어도** 플레이할 수 있는 버전입니다.
GitHub에 새 파일을 올리면 자동으로 배포되고, 휴대폰은 다음에 열 때 "새 버전이 있어요" 알림을 띄웁니다. 세이브는 지워지지 않습니다.

---

## 폴더 구조

```
gd-game/
├─ src/                 ← 개발용 원본 (게임은 여기만 고치면 됨)
│  ├─ index.html        ← 게임 본체 (진입점)
│  ├─ img/              ← 그림
│  ├─ fonts/            ← 글꼴
│  └─ icons/            ← 앱 아이콘
├─ tools/
│  ├─ build.py          ← src → dist 배포용 빌드
│  └─ pwa/              ← 서비스 워커 원본(sw.template.js), 업데이트 알림(pwa.js)
├─ .github/workflows/
│  └─ deploy.yml        ← push하면 자동 빌드·배포
└─ dist/                ← 배포용 결과물 (자동 생성, GitHub에 안 올려도 됨)
```

- **개발용(src)**: 서비스 워커가 없어서 캐시 걱정 없이 바로 확인할 수 있습니다.
- **배포용(dist)**: 빌드할 때 manifest·서비스 워커·버전 번호가 자동으로 붙습니다.

---

## 1. GitHub Pages에 올리기 (처음 한 번)

1. **GitHub 가입** — https://github.com 에서 계정을 만듭니다.
2. **새 저장소 만들기** — 오른쪽 위 `+` → `New repository`
   - Repository name: `gd-game` (원하는 이름)
   - **Public** 선택 (무료 계정은 Public이어야 Pages를 쓸 수 있어요)
   - `Create repository`
3. **파일 올리기** — 저장소 화면에서 `uploading an existing file` 링크를 누르고, zip을 푼 폴더 **안의 내용물 전부**(`src`, `tools`, `.github`, `README.md`, `.gitignore`)를 끌어다 놓은 뒤 `Commit changes`.
   - ⚠ `.github` 폴더는 숨김 폴더라 끌어다 놓을 때 빠질 수 있어요. 올린 뒤 저장소에 `.github` 폴더가 안 보이면:
     `Add file` → `Create new file` → 파일 이름 칸에 `.github/workflows/deploy.yml` 입력 → zip 안의 같은 파일 내용을 붙여넣기 → `Commit changes`.
4. **Pages 켜기** — 저장소 `Settings` → 왼쪽 `Pages` → **Source**를 `GitHub Actions`로 선택.
5. **배포 확인** — 저장소 위쪽 `Actions` 탭에서 `Deploy to GitHub Pages`가 초록색 ✓가 될 때까지 1~3분 기다립니다.
   (빨간 ✗면 오른쪽 `Re-run jobs`를 한 번 눌러 보세요.)
6. **게임 주소** — `Settings → Pages` 맨 위에 주소가 나옵니다.
   보통 `https://내아이디.github.io/gd-game/` 입니다.

## 2. 안드로이드 휴대폰에 설치

1. 휴대폰 **크롬**에서 게임 주소를 엽니다. (처음엔 그림 16MB를 받으니 **와이파이 권장**)
2. 오른쪽 위 **⋮ 메뉴** → **`앱 설치`** (또는 `홈 화면에 추가` → `설치`).
3. 홈 화면에 「괴담근무일지」 아이콘이 생깁니다. 이제 주소창 없이 앱처럼 켜집니다.
4. 한 번 켜서 타이틀이 뜨면 파일이 다 저장된 것입니다. 이후 **비행기 모드에서도 플레이**할 수 있어요.

> 아이폰은 사파리 → 공유 버튼 → `홈 화면에 추가`로 같은 방식으로 설치됩니다.

## 3. 업데이트 올리는 법

1. `src/` 안의 파일(주로 `index.html`, 새 그림은 `img/`)을 고칩니다.
2. GitHub 저장소에서 같은 경로에 파일을 다시 올리고 `Commit changes`.
3. `Actions`에서 초록색 ✓가 뜨면 배포 끝.
4. 휴대폰에서 앱을 열면 아래에 **「새 버전이 있어요 — 업데이트」** 가 뜹니다.
   - `업데이트`: 현재 진행을 저장하고 새 버전으로 다시 켜집니다.
   - `나중에`: 앱을 완전히 껐다(최근 앱에서 밀어서 종료) 다시 켜면 자동으로 새 버전이 됩니다.
   - 전투 중에 누르면 그 전투만 처음부터예요(세이브는 그대로).

## 4. 세이브 데이터

- 세이브는 휴대폰 안(`localStorage`, 키 `gdn3`)에 저장됩니다. 서버·회원가입 필요 없음.
- **업데이트해도 세이브는 지워지지 않습니다.** 업데이트 직전 세이브는 `gdn3_bak_update`에 한 번 더 백업됩니다.
- 세이브가 지워지는 경우: 앱 삭제, 크롬 설정에서 사이트 데이터 삭제, 게임 주소(저장소 이름)를 바꿨을 때.
- 앱이 백그라운드로 가거나 꺼질 때도 자동 저장합니다.

### 버전 마이그레이션 (개발자용)
`src/index.html`의 `loadSave()`가 세이브를 불러올 때:
1. **새 캐릭터·스토리·항목 추가** → 기본값(`DEF()`, 캐릭터별 `N()`)에서 빠진 칸만 자동으로 채웁니다. 따로 할 일 없음.
2. **저장 구조 자체를 바꿀 때**(이름 변경, 형식 변경) → `SAVE_SCHEMA`를 1 올리고 `MIGRATIONS`에 변환 함수를 추가합니다.
   ```js
   const SAVE_KEY='gdn3',SAVE_SCHEMA=2;
   const MIGRATIONS={
     2:s=>{ s.newName = s.oldName; delete s.oldName; },
   };
   ```
3. 마이그레이션 전 원본은 `gdn3_bak`, 깨진 세이브는 `gdn3_broken`에 보관됩니다.

## 5. 내 컴퓨터에서 확인하기 (선택)

```bash
# 개발용 바로 보기 (캐시 없음)
python3 -m http.server 8000 --directory src

# 배포용으로 빌드해서 보기 (PWA·오프라인 확인)
python3 tools/build.py
python3 -m http.server 8000 --directory dist
```
브라우저에서 `http://localhost:8000` 을 엽니다.

## 6. 알아 둘 것

- 실적 평가(PvP), 괴담 제작소 공유, 주간 보스 순위 같은 **온라인 기능은 Claude 버전 전용**이라 이 버전에서는 혼자 하는 방식으로만 동작합니다. 나중에 Supabase 같은 서버를 붙이면 살릴 수 있어요.
- 서비스 워커 원본은 `tools/pwa/`에 있고, `dist/sw.js`는 빌드가 자동으로 만듭니다. `dist/`는 직접 고치지 마세요.
