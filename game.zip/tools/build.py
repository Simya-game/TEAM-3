#!/usr/bin/env python3
"""괴담 근무일지 배포용 빌드.

src/  (개발용 원본)  →  dist/  (GitHub Pages에 올라가는 배포용)

- src의 게임 파일을 그대로 복사한다(게임 코드는 건드리지 않는다).
- index.html <head>에 manifest·아이콘·테마 색을, </body> 앞에 pwa.js를 넣는다.
- 파일 내용으로 버전 해시를 만들어 sw.js / version.json에 넣는다.
  → 파일이 하나라도 바뀌면 버전이 바뀌고, 휴대폰이 새 버전을 감지한다.

사용:  python3 tools/build.py
"""
import hashlib, json, os, shutil, datetime, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, 'src')
DIST = os.path.join(ROOT, 'dist')
PWA = os.path.join(ROOT, 'tools', 'pwa')

SKIP = ('.DS_Store',)


def main():
    if not os.path.exists(os.path.join(SRC, 'index.html')):
        sys.exit('src/index.html 이 없습니다.')
    shutil.rmtree(DIST, ignore_errors=True)
    shutil.copytree(SRC, DIST, ignore=shutil.ignore_patterns(*SKIP, '*_bak*', '*.bak'))

    # 1) 버전: 모든 파일 내용의 해시
    files = []
    for base, _, names in os.walk(DIST):
        for n in sorted(names):
            files.append(os.path.relpath(os.path.join(base, n), DIST).replace(os.sep, '/'))
    files.sort()
    h = hashlib.sha256()
    for f in files:
        h.update(f.encode())
        with open(os.path.join(DIST, f), 'rb') as fp:
            h.update(fp.read())
    for f in ('sw.template.js', 'pwa.js'):
        with open(os.path.join(PWA, f), 'rb') as fp:
            h.update(fp.read())
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d')
    version = f'{stamp}-{h.hexdigest()[:8]}'

    # 2) index.html에 PWA 연결
    ip = os.path.join(DIST, 'index.html')
    html = open(ip, encoding='utf-8').read()
    head = (
        '<link rel="manifest" href="manifest.webmanifest">\n'
        '<meta name="theme-color" content="#0e0609">\n'
        '<meta name="mobile-web-app-capable" content="yes">\n'
        '<meta name="apple-mobile-web-app-capable" content="yes">\n'
        '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">\n'
        '<link rel="icon" type="image/png" sizes="192x192" href="icons/icon-192.png">\n'
        '<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">\n'
        f'<script>window.APP_VERSION="{version}"</script>\n'
    )
    assert '</head>' in html and '</body>' in html, 'index.html 구조를 찾을 수 없습니다.'
    html = html.replace('</head>', head + '</head>', 1)
    html = html.replace('</body>', f'<script src="pwa.js?v={version}"></script>\n</body>', 1)
    open(ip, 'w', encoding='utf-8').write(html)

    # 3) pwa.js, manifest, version.json, .nojekyll
    shutil.copy(os.path.join(PWA, 'pwa.js'), os.path.join(DIST, 'pwa.js'))
    manifest = {
        'name': '괴담 근무일지',
        'short_name': '괴담근무일지',
        'description': '(주)심야관리 현장3팀 — 괴담 수칙서 대조 턴제 RPG',
        'lang': 'ko',
        'id': './',
        'start_url': './',
        'scope': './',
        'display': 'standalone',
        'orientation': 'portrait',
        'background_color': '#0e0609',
        'theme_color': '#0e0609',
        'icons': [
            {'src': 'icons/icon-192.png', 'sizes': '192x192', 'type': 'image/png', 'purpose': 'any'},
            {'src': 'icons/icon-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'any'},
            {'src': 'icons/maskable-192.png', 'sizes': '192x192', 'type': 'image/png', 'purpose': 'maskable'},
            {'src': 'icons/maskable-512.png', 'sizes': '512x512', 'type': 'image/png', 'purpose': 'maskable'},
        ],
    }
    json.dump(manifest, open(os.path.join(DIST, 'manifest.webmanifest'), 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
    json.dump({'version': version}, open(os.path.join(DIST, 'version.json'), 'w'))
    open(os.path.join(DIST, '.nojekyll'), 'w').close()

    # 4) sw.js (미리 받아 둘 파일 목록 = dist 전체)
    assets = ['./', './index.html', './manifest.webmanifest', f'./pwa.js?v={version}'] + \
             ['./' + f for f in files if f != 'index.html']
    sw = open(os.path.join(PWA, 'sw.template.js'), encoding='utf-8').read()
    sw = sw.replace('__VERSION__', version).replace('__ASSETS__', json.dumps(assets, ensure_ascii=False))
    open(os.path.join(DIST, 'sw.js'), 'w', encoding='utf-8').write(sw)

    size = sum(os.path.getsize(os.path.join(b, n)) for b, _, ns in os.walk(DIST) for n in ns)
    print(f'빌드 완료  version={version}  파일 {len(assets)}개  {size/1024/1024:.1f}MB  → dist/')


if __name__ == '__main__':
    main()
