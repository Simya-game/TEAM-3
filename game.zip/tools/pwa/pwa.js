/* 괴담 근무일지 PWA 연결 스크립트 — 서비스 워커 등록 + 새 버전 알림. 배포용(dist)에만 들어간다. */
(function () {
  if (!('serviceWorker' in navigator) || location.protocol === 'file:') return;

  // 브라우저가 저장 공간을 정리할 때 세이브가 지워지지 않게 "영구 저장"을 요청한다.
  if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});

  const inBattle = () => { try { return typeof B !== 'undefined' && B && !B.over; } catch (e) { return false; } };

  function showUpdate(worker) {
    if (document.getElementById('pwaUpd')) return;
    const bar = document.createElement('div');
    bar.id = 'pwaUpd';
    bar.style.cssText = 'position:fixed;left:8px;right:8px;bottom:calc(8px + env(safe-area-inset-bottom));z-index:9999;background:rgba(14,6,9,.97);border:1px solid #d3283a;border-radius:8px;padding:10px 12px;color:#f3e6e6;font:14px/1.4 system-ui,sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.6);display:flex;gap:8px;align-items:center';
    const msg = document.createElement('div');
    msg.style.flex = '1';
    msg.innerHTML = '<b style="color:#ffd36a">새 버전이 있어요</b><br><small>' +
      (inBattle() ? '전투 중이에요. 지금 업데이트하면 이번 전투는 처음부터예요.' : '진행 상황은 저장된 채로 업데이트돼요.') + '</small>';
    const go = document.createElement('button');
    go.textContent = '업데이트';
    go.style.cssText = 'background:#d3283a;color:#fff;border:0;border-radius:6px;padding:8px 12px;font-weight:700';
    const later = document.createElement('button');
    later.textContent = '나중에';
    later.style.cssText = 'background:transparent;color:#c9a9a9;border:1px solid #4a2a30;border-radius:6px;padding:8px 10px';
    go.onclick = () => {
      try { if (typeof save === 'function') save(); } catch (e) {}
      try { const raw = localStorage.getItem('gdn3'); if (raw) localStorage.setItem('gdn3_bak_update', raw); } catch (e) {}
      go.disabled = true; go.textContent = '적용 중…';
      worker.postMessage({ type: 'SKIP_WAITING' });
    };
    later.onclick = () => bar.remove(); // 다음에 앱을 완전히 껐다 켜면 자동으로 새 버전이 적용된다
    bar.append(msg, go, later);
    document.body.appendChild(bar);
  }

  let reloading = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (reloading) return;
    reloading = true;
    location.reload();
  });

  window.addEventListener('load', async () => {
    try {
      const reg = await navigator.serviceWorker.register('./sw.js', { scope: './' });
      if (reg.waiting && navigator.serviceWorker.controller) showUpdate(reg.waiting);
      reg.addEventListener('updatefound', () => {
        const w = reg.installing;
        if (!w) return;
        w.addEventListener('statechange', () => {
          if (w.state === 'installed' && navigator.serviceWorker.controller) showUpdate(w);
        });
      });
      // 앱을 다시 볼 때마다, 그리고 30분마다 새 버전 확인
      document.addEventListener('visibilitychange', () => { if (!document.hidden) reg.update().catch(() => {}); });
      setInterval(() => reg.update().catch(() => {}), 30 * 60 * 1000);
    } catch (e) {
      console.warn('서비스 워커 등록 실패', e);
    }
  });
})();
