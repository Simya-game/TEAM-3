/* 괴담 근무일지 서비스 워커 — tools/build.py가 VERSION과 ASSETS를 채워서 dist/sw.js로 만든다. 직접 고치지 말 것. */
const VERSION = '__VERSION__';
const CACHE = 'gd-' + VERSION;
const ASSETS = __ASSETS__;

// 설치: 이번 버전 파일을 전부 미리 받아 둔다(오프라인 플레이용).
// skipWaiting은 하지 않는다 → 게임 중에 갑자기 버전이 바뀌지 않게, 플레이어가 "업데이트"를 눌렀을 때만 교체.
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c =>
      Promise.all(ASSETS.map(u => c.add(new Request(u, { cache: 'reload' })).catch(err => console.warn('precache 실패', u, err))))
    )
  );
});

// 활성화: 이전 버전 캐시만 지운다. localStorage(세이브)는 건드리지 않는다.
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k.startsWith('gd-') && k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', e => {
  if (e.data && e.data.type === 'SKIP_WAITING') self.skipWaiting();
});

// 요청 처리: 같은 사이트 파일은 캐시 우선(오프라인 OK), 없으면 네트워크에서 받아 캐시에 넣는다.
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  if (url.pathname.endsWith('/version.json')) return; // 버전 확인은 항상 네트워크

  if (req.mode === 'navigate') {
    e.respondWith(
      caches.match('./index.html', { ignoreSearch: true }).then(r => r || fetch(req))
    );
    return;
  }
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then(hit => hit || fetch(req).then(res => {
      if (res && res.ok && res.type === 'basic') {
        const copy = res.clone();
        caches.open(CACHE).then(c => c.put(req, copy));
      }
      return res;
    }))
  );
});
